#!/usr/bin/env python3
"""
EFD-ICMS/IPI — Visualizador de Registros
Guia Prático v3.2.1
"""

import json
import os
import sys
import tkinter as tk
from tkinter import filedialog, messagebox

# ─────────────────────────────────────────────────────────────────────────────
#  TEMA — claro, limpo, profissional
# ─────────────────────────────────────────────────────────────────────────────
T = {
    "win_bg":       "#F0F2F5",
    "panel_bg":     "#FFFFFF",
    "sidebar_bg":   "#F7F8FA",
    "row_odd":      "#FFFFFF",
    "row_even":     "#F4F6FA",
    "row_hover":    "#E8F0FE",
    "row_sel":      "#D2E3FC",
    "hdr_bg":       "#E4EAF5",
    "sec_hdr":      "#EEF2F8",
    "bloco_bg":     "#DDE5F5",
    "border":       "#D0D7E4",
    "fg_main":      "#1A1D23",
    "fg_sec":       "#5A6478",
    "fg_dim":       "#9EA8BC",
    "fg_bloco":     "#2C4A8C",
    "fg_num":       "#1558D6",
    "fg_campo":     "#0B5394",
    "fg_obrig_O":   "#1E7E34",
    "fg_obrig_OC":  "#895A00",
    "fg_tipo_C":    "#0B5394",
    "fg_tipo_N":    "#1E7E34",
    "fg_tipo_D":    "#7B3F00",
    "fg_accent":    "#1558D6",
    "status_bg":    "#E4E9F2",
    "status_fg":    "#5A6478",
}

UI   = "Segoe UI"
MONO = "Consolas"

BLOCOS = {
    "0": "Bloco 0 — Abertura e Referências",
    "B": "Bloco B — ISS",
    "C": "Bloco C — NF e Documentos Fiscais",
    "D": "Bloco D — Serviços de Transporte",
    "E": "Bloco E — Apuração de Impostos",
    "G": "Bloco G — CIAP",
    "H": "Bloco H — Inventário",
    "K": "Bloco K — Produção e Estoque",
    "1": "Bloco 1 — Outras Informações",
    "9": "Bloco 9 — Controle e Encerramento",
}


def bloco_key(numero):
    return numero[0] if numero else "?"


def get_app_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def find_json():
    base = get_app_dir()
    for p in [
        os.path.join(base, "efd_registros_estrutura_regras.json"),
        os.path.join(base, "efd_registros.json"),
    ]:
        if os.path.exists(p):
            return p
    return ""


def clean_text(text):
    if not text:
        return ""
    lines = [ln.strip() for ln in text.split("\n")]
    result, prev_blank = [], False
    for ln in lines:
        if ln == "":
            if not prev_blank:
                result.append("")
            prev_blank = True
        else:
            result.append(ln)
            prev_blank = False
    return "\n".join(result).strip()


def format_bloco_value(bloco):
    if not bloco:
        return "—"
    bloco = str(bloco).strip()
    if bloco in BLOCOS:
        return BLOCOS[bloco]
    return bloco


def format_filhos_diretos(filhos):
    if not filhos:
        return ["• Nenhum"]
    return [f"• {filho}" for filho in filhos]


# ─────────────────────────────────────────────────────────────────────────────
#  SCROLL FRAME
# ─────────────────────────────────────────────────────────────────────────────

class VScrollFrame(tk.Frame):
    def __init__(self, parent, bg, **kw):
        super().__init__(parent, bg=bg, **kw)
        self._bg = bg
        self._canvas = tk.Canvas(self, bg=bg, highlightthickness=0, bd=0)
        self._sb = tk.Scrollbar(self, orient="vertical",
                                command=self._canvas.yview)
        self._canvas.configure(yscrollcommand=self._sb.set)
        self._sb.pack(side="right", fill="y")
        self._canvas.pack(side="left", fill="both", expand=True)
        self.inner = tk.Frame(self._canvas, bg=bg)
        self._win = self._canvas.create_window((0, 0), window=self.inner,
                                               anchor="nw")
        self.inner.bind("<Configure>", self._on_inner)
        self._canvas.bind("<Configure>", self._on_canvas)
        self._canvas.bind("<MouseWheel>", self._scroll)
        self.inner.bind("<MouseWheel>", self._scroll)

    def _on_inner(self, _):
        self._canvas.configure(scrollregion=self._canvas.bbox("all"))

    def _on_canvas(self, e):
        self._canvas.itemconfig(self._win, width=e.width)

    def _scroll(self, e):
        self._canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")

    def bind_scroll(self, w):
        w.bind("<MouseWheel>", self._scroll)

    def to_top(self):
        self._canvas.yview_moveto(0)


# ─────────────────────────────────────────────────────────────────────────────
#  APP
# ─────────────────────────────────────────────────────────────────────────────

class App(tk.Tk):

    def __init__(self):
        super().__init__()
        self.title("SPED - Manual Digital")
        self.geometry("1400x840")
        self.minsize(900, 560)
        self.configure(bg=T["win_bg"])

        self._data = []
        self._filtered = []
        self._search_var = tk.StringVar()
        self._search_var.trace_add("write", self._on_search)

        self._reg_by_code = {}
        self._order_map = {}
        self._children_by_parent = {}
        self._expanded_nodes = set()

        self._build()
        self._load_auto()

    # ── UI ───────────────────────────────────────────────────────────────────

    def _build(self):
        self._build_topbar()

        main = tk.Frame(self, bg=T["win_bg"])
        main.pack(fill="both", expand=True)

        # Sidebar fixa
        self._sidebar = tk.Frame(main, bg=T["sidebar_bg"], width=370)
        self._sidebar.pack(side="left", fill="y")
        self._sidebar.pack_propagate(False)

        tk.Frame(main, bg=T["border"], width=1).pack(side="left", fill="y")

        # Direita expansível
        self._right = tk.Frame(main, bg=T["win_bg"])
        self._right.pack(side="left", fill="both", expand=True)

        self._build_sidebar()
        self._build_right()

        # Status
        tk.Frame(self, bg=T["border"], height=1).pack(fill="x", side="bottom")
        self._status = tk.Label(self, text="  Nenhum arquivo carregado.",
                                bg=T["status_bg"], fg=T["status_fg"],
                                font=(UI, 8), anchor="w", padx=12, pady=3)
        self._status.pack(fill="x", side="bottom")

    def _build_topbar(self):
        bar = tk.Frame(self, bg=T["panel_bg"])
        bar.pack(fill="x")
        tk.Frame(bar, bg=T["border"], height=1).pack(fill="x", side="bottom")
        tk.Label(bar, text="SPED - Manual Digital", bg=T["panel_bg"],
                 fg=T["fg_num"], font=(UI, 13, "bold"),
                 pady=10, padx=16).pack(side="left")
        tk.Label(bar, text="Visualizador de Registros", bg=T["panel_bg"],
                 fg=T["fg_sec"], font=(UI, 11), pady=10).pack(side="left")
        btn = tk.Button(bar, text="  Abrir JSON…  ",
                        bg=T["fg_accent"], fg="white",
                        activebackground="#0D47A1", activeforeground="white",
                        relief="flat", bd=0,
                        font=(UI, 9, "bold"),
                        padx=10, pady=6, cursor="hand2",
                        command=self._open_file)
        btn.pack(side="right", padx=12, pady=6)

    def _build_sidebar(self):
        sb = self._sidebar

        # Busca
        sw = tk.Frame(sb, bg=T["sidebar_bg"], pady=8, padx=10)
        sw.pack(fill="x")
        ef = tk.Frame(sw, bg="white",
                      highlightbackground=T["border"],
                      highlightthickness=1, bd=0)
        ef.pack(fill="x")
        tk.Label(ef, text="🔍", bg="white", fg=T["fg_dim"],
                 font=(UI, 10), padx=6).pack(side="left")
        self._entry = tk.Entry(ef, textvariable=self._search_var,
                               bg="white", fg=T["fg_main"],
                               insertbackground=T["fg_accent"],
                               relief="flat", bd=0,
                               font=(UI, 10))
        self._entry.pack(side="left", fill="x", expand=True,
                         ipady=6, ipadx=2)
        tk.Button(ef, text="✕", bg="white", fg=T["fg_dim"],
                  activebackground=T["row_hover"],
                  relief="flat", bd=0, font=(UI, 9),
                  cursor="hand2",
                  command=self._clear_search).pack(side="right", padx=4)

        def fi(_):
            ef.config(highlightbackground=T["fg_accent"], highlightthickness=2)

        def fo(_):
            ef.config(highlightbackground=T["border"], highlightthickness=1)

        self._entry.bind("<FocusIn>", fi)
        self._entry.bind("<FocusOut>", fo)

        self._lbl_count = tk.Label(sb, text="", bg=T["sidebar_bg"],
                                   fg=T["fg_dim"], font=(UI, 8),
                                   anchor="e", padx=12)
        self._lbl_count.pack(fill="x")
        tk.Frame(sb, bg=T["border"], height=1).pack(fill="x")

        # Lista
        self._list_sf = VScrollFrame(sb, bg=T["sidebar_bg"])
        self._list_sf.pack(fill="both", expand=True)
        self._list_inner = self._list_sf.inner
        self._list_widgets = []

    def _build_right(self):
        r = self._right

        # Header do registro selecionado
        self._det_hdr = tk.Frame(r, bg=T["panel_bg"])
        self._det_hdr.pack(fill="x")
        tk.Frame(r, bg=T["border"], height=1).pack(fill="x")

        self._lbl_num = tk.Label(self._det_hdr, text="",
                                 bg=T["panel_bg"], fg=T["fg_num"],
                                 font=(MONO, 13, "bold"),
                                 padx=20, pady=14, anchor="w")
        self._lbl_num.pack(side="left")

        self._lbl_nome = tk.Label(self._det_hdr,
                                  text="← Selecione um registro na lista",
                                  bg=T["panel_bg"], fg=T["fg_sec"],
                                  font=(UI, 12),
                                  padx=4, pady=14, anchor="w")
        self._lbl_nome.pack(side="left", fill="x", expand=True)

        # Corpo scrollável
        self._det_sf = VScrollFrame(r, bg=T["win_bg"])
        self._det_sf.pack(fill="both", expand=True)
        self._det_body = self._det_sf.inner

    # ── Dados ────────────────────────────────────────────────────────────────

    def _load_auto(self):
        p = find_json()
        if p:
            self._load(p)

    def _open_file(self):
        p = filedialog.askopenfilename(
            title="Selecionar efd_registros.json",
            filetypes=[("JSON", "*.json"), ("Todos", "*.*")]
        )
        if p:
            self._load(p)

    def _load(self, path):
        try:
            with open(path, encoding="utf-8") as f:
                self._data = json.load(f)
            self._filtered = list(self._data)
            self._rebuild_indexes()
            self._expand_all_with_children()
            self._status.config(
                text=f"  ✓  {os.path.basename(path)}   —   {len(self._data)} registros carregados"
            )
            self._render_list()
            self._update_count()
        except Exception as e:
            messagebox.showerror("Erro", str(e))

    def _rebuild_indexes(self):
        self._reg_by_code = {}
        self._order_map = {}
        self._children_by_parent = {}

        for idx, reg in enumerate(self._data):
            codigo = reg.get("numero", "")
            if not codigo:
                continue
            self._reg_by_code[codigo] = reg
            self._order_map[codigo] = idx

        for reg in self._data:
            codigo = reg.get("numero", "")
            er = reg.get("estrutura_regras") or {}
            pai = er.get("registro_pai")
            if pai:
                self._children_by_parent.setdefault(pai, []).append(codigo)

        for pai, filhos in self._children_by_parent.items():
            filhos.sort(key=lambda c: self._order_map.get(c, 10**9))

    def _expand_all_with_children(self):
        self._expanded_nodes = set(self._children_by_parent.keys())

    # ── Pesquisa ──────────────────────────────────────────────────────────────

    def _on_search(self, *_):
        q = self._search_var.get().strip().lower()
        self._filtered = [
            r for r in self._data
            if not q or q in r["numero"].lower() or q in r["nome"].lower()
        ]
        self._render_list()
        self._update_count()

        if q:
            correspondencias_exatas = [
                r for r in self._data
                if q == r.get("numero", "").strip().lower()
            ]
            if len(correspondencias_exatas) == 1:
                self._show(correspondencias_exatas[0])

    def _clear_search(self):
        self._search_var.set("")
        self._entry.focus_set()

    def _update_count(self):
        n, t = len(self._filtered), len(self._data)
        if t == 0:
            txt, fg = "", T["fg_dim"]
        elif n == t:
            txt, fg = f"{t} registros  ", T["fg_dim"]
        else:
            txt, fg = f"{n} de {t} registros  ", T["fg_obrig_OC"]
        self._lbl_count.config(text=txt, fg=fg)

    # ── Lista / Árvore ───────────────────────────────────────────────────────

    def _render_list(self):
        for w in self._list_widgets:
            try:
                w.destroy()
            except Exception:
                pass
        self._list_widgets.clear()

        parent = self._list_inner

        if not self._filtered:
            lbl = tk.Label(parent, text="\nNenhum resultado.",
                           bg=T["sidebar_bg"], fg=T["fg_dim"],
                           font=(UI, 10))
            lbl.pack(pady=30)
            self._list_widgets.append(lbl)
            return

        filtered_codes = {r.get("numero") for r in self._filtered if r.get("numero")}
        visible_codes = set(filtered_codes)

        # Em pesquisa, inclui ancestrais para manter o encadeamento em árvore.
        if self._search_var.get().strip():
            for codigo in list(filtered_codes):
                visible_codes.update(self._collect_ancestors(codigo))

        blocos_ord, blocos_map = [], {}
        for codigo in sorted(visible_codes, key=lambda c: self._order_map.get(c, 10**9)):
            reg = self._reg_by_code.get(codigo)
            if not reg:
                continue
            bk = bloco_key(reg.get("numero", ""))
            if bk not in blocos_map:
                blocos_map[bk] = []
                blocos_ord.append(bk)
            blocos_map[bk].append(reg)

        for bk in blocos_ord:
            regs = blocos_map[bk]
            regs_by_code = {r["numero"]: r for r in regs if r.get("numero")}

            hdr = tk.Frame(parent, bg=T["bloco_bg"])
            hdr.pack(fill="x", pady=(6, 0))
            tk.Label(hdr, text=f"  {BLOCOS.get(bk, 'Bloco ' + bk)}",
                     bg=T["bloco_bg"], fg=T["fg_bloco"],
                     font=(UI, 8, "bold"), anchor="w",
                     pady=5).pack(side="left")
            tk.Label(hdr, text=f"{len(regs)}  ",
                     bg=T["bloco_bg"], fg=T["fg_dim"],
                     font=(UI, 8)).pack(side="right")
            self._list_widgets.append(hdr)

            root_codes = []
            for reg in regs:
                codigo = reg.get("numero", "")
                pai = (reg.get("estrutura_regras") or {}).get("registro_pai")
                if not pai or pai not in regs_by_code:
                    root_codes.append(codigo)

            root_codes.sort(key=lambda c: self._order_map.get(c, 10**9))
            row_idx = 0
            for codigo in root_codes:
                row_idx = self._render_tree_node(parent, codigo, regs_by_code, visible_codes, 0, row_idx)

        self._list_sf.to_top()

    def _render_tree_node(self, parent, codigo, regs_by_code, visible_codes, depth, row_idx):
        reg = regs_by_code.get(codigo)
        if not reg:
            return row_idx

        children = [
            child for child in self._children_by_parent.get(codigo, [])
            if child in visible_codes and child in regs_by_code
        ]
        has_children = bool(children)
        is_expanded = codigo in self._expanded_nodes

        bg = T["row_even"] if row_idx % 2 == 0 else T["row_odd"]
        item = tk.Frame(parent, bg=bg, cursor="hand2")
        item.pack(fill="x")

        indent = tk.Frame(item, bg=bg, width=12 + depth * 18)
        indent.pack(side="left")
        indent.pack_propagate(False)

        if has_children:
            toggle = tk.Label(item,
                              text="▾" if is_expanded else "▸",
                              bg=bg, fg=T["fg_dim"],
                              font=(UI, 9, "bold"),
                              width=2, anchor="center", pady=6,
                              cursor="hand2")
        else:
            toggle = tk.Label(item,
                              text=" ",
                              bg=bg, fg=T["fg_dim"],
                              font=(UI, 9),
                              width=2, anchor="center", pady=6)
        toggle.pack(side="left")

        ln = tk.Label(item, text=f" {reg['numero']} ",
                      bg=bg, fg=T["fg_num"],
                      font=(MONO, 9, "bold"),
                      width=7, anchor="w", pady=6)
        ln.pack(side="left")

        nome = reg["nome"]
        if len(nome) > 52:
            nome = nome[:52] + "…"
        lnome = tk.Label(item, text=nome,
                         bg=bg, fg=T["fg_main"],
                         font=(UI, 9), anchor="w", pady=6)
        lnome.pack(side="left", fill="x", expand=True, padx=(0, 8))

        ws = [item, indent, toggle, ln, lnome]

        def _e(e, ws=ws):
            for w in ws:
                w.config(bg=T["row_hover"])

        def _l(e, ws=ws, b=bg):
            for w in ws:
                w.config(bg=b)

        def _c(e, r=reg):
            self._show(r)

        for w in ws:
            w.bind("<Enter>", _e)
            w.bind("<Leave>", _l)

        item.bind("<Button-1>", _c)
        ln.bind("<Button-1>", _c)
        lnome.bind("<Button-1>", _c)
        indent.bind("<Button-1>", _c)

        if has_children:
            def _toggle(e=None, code=codigo):
                if code in self._expanded_nodes:
                    self._expanded_nodes.remove(code)
                else:
                    self._expanded_nodes.add(code)
                self._render_list()
                self._update_count()
                return "break"

            toggle.bind("<Button-1>", _toggle)

        self._list_widgets.append(item)
        row_idx += 1

        if has_children and is_expanded:
            for child_code in children:
                row_idx = self._render_tree_node(parent, child_code, regs_by_code, visible_codes, depth + 1, row_idx)

        return row_idx

    def _collect_ancestors(self, codigo):
        ancestors = []
        seen = set()
        current = codigo
        while True:
            reg = self._reg_by_code.get(current)
            if not reg:
                break
            pai = (reg.get("estrutura_regras") or {}).get("registro_pai")
            if not pai or pai in seen:
                break
            ancestors.append(pai)
            seen.add(pai)
            current = pai
        return ancestors

    # ── Detalhe ───────────────────────────────────────────────────────────────

    def _show(self, reg):
        self._lbl_num.config(text=f"REGISTRO {reg['numero']}")
        self._lbl_nome.config(text=reg["nome"], fg=T["fg_main"])

        # Limpa corpo
        for w in list(self._det_body.winfo_children()):
            w.destroy()

        d = reg.get("descricao", {})
        texto = clean_text(d.get("texto") or "")
        campos = d.get("campos") or []
        obs = clean_text(d.get("observacoes") or "")
        val = clean_text(d.get("validacoes") or "")

        tk.Frame(self._det_body, bg=T["win_bg"], height=8).pack(fill="x")

        # ─────────────────────────────────────────
        # Estrutura e Regras (novo painel)
        # ─────────────────────────────────────────
        er = reg.get("estrutura_regras") or {}

        if er:
            self._sec(self._det_body, "Estrutura e Regras")

            bloco = format_bloco_value(er.get("bloco"))
            codigo = reg.get("numero") or "—"
            nome = reg.get("nome") or "—"
            papel = er.get("papel_funcional") or "—"
            pai = er.get("registro_pai") or "—"
            gatilho = er.get("gatilho") or "—"
            filhos = er.get("filhos_diretos") or []

            linhas = []
            linhas.append(f"Bloco: {bloco}")
            linhas.append(f"Código: {codigo}")
            linhas.append(f"Nome: {nome}")
            linhas.append(f"Papel funcional: {papel}")
            linhas.append(f"Registro pai: {pai}")
            linhas.append(f"Gatilho: {gatilho}")
            linhas.append("")
            linhas.append("Filhos diretos:")
            linhas.extend(format_filhos_diretos(filhos))

            texto_resumo = "\n".join(linhas)
            self._textbox_scrolled(self._det_body, texto_resumo, height=10)

        if texto:
            self._sec(self._det_body, "Descrição")
            self._textbox_scrolled(self._det_body, texto, height=10)

        if campos:
            self._sec(self._det_body,
                      f"Estrutura do Registro   ·   {len(campos)} campos")
            self._table(self._det_body, campos)

        if obs:
            self._sec(self._det_body, "Observações")
            self._textbox_scrolled(self._det_body, obs, fg=T["fg_sec"], height=4)

        if val:
            self._sec(self._det_body, "Validações e Preenchimento")
            self._textbox_scrolled(self._det_body, val)

        tk.Frame(self._det_body, bg=T["win_bg"], height=20).pack(fill="x")
        self._det_sf.to_top()

    def _sec(self, parent, title):
        hdr = tk.Frame(parent, bg=T["sec_hdr"])
        hdr.pack(fill="x", padx=20, pady=(12, 0))
        tk.Label(hdr, text=f"  {title}",
                 bg=T["sec_hdr"], fg=T["fg_bloco"],
                 font=(UI, 8, "bold"), anchor="w",
                 pady=5).pack(fill="x")
        tk.Frame(parent, bg=T["border"], height=1).pack(fill="x", padx=20)

    def _textbox(self, parent, text, fg=None):
        """Caixa de texto simples com altura auto-ajustada (sem scrollbar propria)."""
        fg = fg or T["fg_main"]
        lines = text.split("\n")
        n = sum(max(1, len(ln) // 85 + 1) for ln in lines)
        h = min(max(n, 1), 28)

        txt = tk.Text(parent,
                      bg=T["panel_bg"], fg=fg,
                      font=(UI, 10),
                      relief="flat", bd=0,
                      wrap="word",
                      padx=16, pady=10,
                      cursor="arrow",
                      height=h,
                      selectbackground=T["row_sel"])
        txt.insert("1.0", text)
        txt.config(state="disabled")
        txt.pack(fill="x", padx=20, pady=(0, 4))
        self._det_sf.bind_scroll(txt)

    def _textbox_scrolled(self, parent, text, fg=None, height=18):
        """
        Caixa de texto com scrollbar vertical sempre visivel.
        Usada para secoes com conteudo potencialmente longo (Validacoes).
        """
        fg = fg or T["fg_main"]

        outer = tk.Frame(parent, bg=T["win_bg"])
        outer.pack(fill="x", padx=20, pady=(0, 4))

        frame = tk.Frame(outer, bg=T["panel_bg"],
                         highlightbackground=T["border"],
                         highlightthickness=1)
        frame.pack(fill="x")

        sb = tk.Scrollbar(frame, orient="vertical",
                          bg=T["border"], troughcolor=T["panel_bg"],
                          relief="flat", bd=0, width=12)
        sb.pack(side="right", fill="y")

        txt = tk.Text(frame,
                      bg=T["panel_bg"], fg=fg,
                      font=(UI, 10),
                      relief="flat", bd=0,
                      wrap="word",
                      padx=16, pady=10,
                      cursor="arrow",
                      height=height,
                      yscrollcommand=sb.set,
                      selectbackground=T["row_sel"])
        txt.pack(side="left", fill="both", expand=True)
        sb.config(command=txt.yview)

        txt.insert("1.0", text)
        txt.config(state="disabled")

        # MouseWheel dentro do Text rola o proprio Text (nao propaga para o painel externo)
        def _on_wheel(e):
            txt.yview_scroll(int(-1 * (e.delta / 120)), "units")
            return "break"
        txt.bind("<MouseWheel>", _on_wheel)

    def _table(self, parent, campos):
        outer = tk.Frame(parent, bg=T["win_bg"])
        outer.pack(fill="x", padx=20, pady=(0, 6))

        # Cabeçalho da tabela
        hdr = tk.Frame(outer, bg=T["hdr_bg"])
        hdr.pack(fill="x")
        COLS = [
            ("Nº",        3,  "center"),
            ("Campo",     20, "w"),
            ("Tipo",      5,  "center"),
            ("Tam",       7,  "center"),
            ("Dec",       4,  "center"),
            ("Obrig.",    5,  "center"),
            ("Descrição", 0,  "w"),
        ]
        for text, w, anc in COLS:
            kw = dict(bg=T["hdr_bg"], fg=T["fg_bloco"],
                      font=(UI, 8, "bold"),
                      padx=8, pady=6, relief="flat", anchor=anc)
            if w:
                kw["width"] = w
            tk.Label(hdr, text=text, **kw).pack(side="left")

        # Linhas
        for i, c in enumerate(campos):
            bg = T["row_even"] if i % 2 == 0 else T["row_odd"]
            row = tk.Frame(outer, bg=bg)
            row.pack(fill="x")

            num = str(c.get("num", ""))
            campo = c.get("campo", "")
            tipo = c.get("tipo", "")
            tam = c.get("tam", "")
            dec = c.get("dec", "")
            obrig = c.get("obrig", "")
            desc = c.get("descricao", "")

            tipo_fg = {"C": T["fg_tipo_C"], "N": T["fg_tipo_N"],
                       "D": T["fg_tipo_D"]}.get(tipo, T["fg_sec"])
            obrig_fg = {"O": T["fg_obrig_O"],
                        "OC": T["fg_obrig_OC"]}.get(obrig, T["fg_dim"])

            def lbl(text, w=0, fg=T["fg_main"], font=(UI, 9),
                    anchor="w", r=row, b=bg):
                kw = dict(bg=b, fg=fg, font=font, padx=8,
                          pady=5, anchor=anchor)
                if w:
                    kw["width"] = w
                return tk.Label(r, text=text, **kw)

            lbl(num,   w=3,  fg=T["fg_dim"], font=(MONO, 9),
                anchor="center").pack(side="left")
            lbl(campo, w=20, fg=T["fg_campo"], font=(MONO, 9, "bold"),
                anchor="w").pack(side="left")
            lbl(tipo,  w=5,  fg=tipo_fg, font=(MONO, 9, "bold"),
                anchor="center").pack(side="left")
            lbl(tam,   w=7,  fg=T["fg_sec"], font=(MONO, 9),
                anchor="center").pack(side="left")
            lbl(dec,   w=4,  fg=T["fg_sec"], font=(MONO, 9),
                anchor="center").pack(side="left")
            lbl(obrig, w=5,  fg=obrig_fg, font=(UI, 8, "bold"),
                anchor="center").pack(side="left")

            # Descrição
            if len(desc) > 65:
                df = tk.Frame(row, bg=bg)
                df.pack(side="left", fill="x", expand=True, padx=(4, 10), pady=2)
                nl = max(1, len(desc) // 70 + desc.count("\n") + 1)
                t = tk.Text(df, bg=bg, fg=T["fg_main"],
                            font=(UI, 9), relief="flat", bd=0,
                            wrap="word", cursor="arrow",
                            padx=0, pady=3,
                            height=min(nl, 6),
                            selectbackground=T["row_sel"])
                t.insert("1.0", desc)
                t.config(state="disabled")
                t.pack(fill="x")
                self._det_sf.bind_scroll(t)
                t.bind("<Enter>", lambda e, r=row, ch=list(row.winfo_children()) + [t], b=bg:
                       self._row_hover(r, ch, True))
                t.bind("<Leave>", lambda e, r=row, ch=list(row.winfo_children()) + [t], b=bg:
                       self._row_hover(r, ch, False, b))
            else:
                tk.Label(row, text=desc, bg=bg, fg=T["fg_main"],
                         font=(UI, 9), anchor="w", padx=4, pady=5,
                         wraplength=500, justify="left"
                         ).pack(side="left", fill="x", expand=True)

            children = list(row.winfo_children())
            row.bind("<Enter>", lambda e, r=row, ch=children, b=bg:
                     self._row_hover(r, ch, True))
            row.bind("<Leave>", lambda e, r=row, ch=children, b=bg:
                     self._row_hover(r, ch, False, b))
            for ch in children:
                ch.bind("<Enter>", lambda e, r=row, c=children, b=bg:
                        self._row_hover(r, c, True))
                ch.bind("<Leave>", lambda e, r=row, c=children, b=bg:
                        self._row_hover(r, c, False, b))

        # Legenda
        leg = tk.Frame(outer, bg=T["sec_hdr"])
        leg.pack(fill="x")
        for txt, fg in [
            ("  Tipo: ", T["fg_dim"]),
            ("C = Caractere  ", T["fg_tipo_C"]),
            ("N = Numérico  ", T["fg_tipo_N"]),
            ("D = Data    ", T["fg_tipo_D"]),
            ("Obrig.: ", T["fg_dim"]),
            ("O = Obrigatório  ", T["fg_obrig_O"]),
            ("OC = Obrigatório Condicional  ", T["fg_obrig_OC"]),
        ]:
            bold = fg != T["fg_dim"]
            tk.Label(leg, text=txt, bg=T["sec_hdr"], fg=fg,
                     font=(UI, 7, "bold" if bold else "normal"),
                     pady=4).pack(side="left")

    @staticmethod
    def _row_hover(row, children, entering, bg=None):
        col = T["row_hover"] if entering else bg
        if col is None:
            return
        try:
            row.config(bg=col)
        except Exception:
            pass
        for w in children:
            try:
                w.config(bg=col)
            except Exception:
                pass


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    App().mainloop()
